package account;

import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

import org.testng.annotations.BeforeTest;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;

public class Login 
{
	WebDriver driver;
	@Test

	public void login() throws IOException 
	{
		File f = new File ("D:\\Finaltutorialsninja\\Data\\SignaUp.xlsx");
		FileInputStream fis =new FileInputStream(f);
		XSSFWorkbook wk = new XSSFWorkbook(fis);
		XSSFSheet sh= wk.getSheet("Sheet2");
		int size= sh.getLastRowNum();

		for (int i=0; i<=size; i++)
		{ 


			WebDriverWait wait =new WebDriverWait(driver,20);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'My Account')]")));
			driver.findElement(By.xpath("//span[contains(text(),'My Account')]")).click();
			
			//wd.findElement(By.xpath("//span[contains(text(),'My Account')]"));
			driver.findElement(By.xpath("/html/body/nav/div/div[2]/ul/li[2]/ul/li[2]/a")).click();
			
			String u = sh.getRow(i).getCell(0).toString();
			String p= sh.getRow(i).getCell(1).toString();
			WebElement usernm = driver.findElement(By.name("email"));
			WebElement pswd = driver.findElement(By.name("password"));
			WebElement login = driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[1]/div[2]/div[1]/form[1]/input[1]"));
			System.out.print(u+  " |   " +p);
			usernm.sendKeys(u);
			pswd.sendKeys(p);
			login.click();
			
			try
			{

				
				driver.findElement(By.linkText("Logout")).click();
				

			}
			catch(Exception e)
			{
				System.out.print("---- Invalid username/password");
			}

			System.out.println();
			
		}
	}

	@BeforeTest
	public void beforeTest() 
	{
		WebDriverManager.chromedriver().setup();
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://tutorialsninja.com/demo/index.php?route=common/home");
	}

	@AfterTest
	public void afterTest()
	{
		driver.close();  
	}

}
