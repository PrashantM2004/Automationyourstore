package alllinks;

import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

import org.testng.annotations.BeforeTest;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

public class links 
{
	WebDriver driver;
  @Test
  public void link() throws IOException 
  {
	  List<WebElement> links =driver.findElements(By.tagName("a"));
		int size=links.size();

		File f =new File("D:\\Finaltutorialsninja\\Data\\SignaUp.xlsx");
		FileInputStream fis =new FileInputStream(f);
		XSSFWorkbook wk = new XSSFWorkbook(fis);
		XSSFSheet sh =wk.getSheet("Sheet4");
		
		FileOutputStream fos = new FileOutputStream(f);
		int size1= sh.getLastRowNum();
		
		for (int i=1; i<size1; i++)
		{
			String str=links.get(i).getText();
			sh.createRow(i).createCell(0).setCellValue(str);
			System.out.println(links.get(i).getText());
		}
		
		sh.createRow(0).createCell(0).setCellValue(size);

			wk.write(fos);
			fos.close();
			System.out.println("Success !!");
			
	  
  }
  @BeforeTest
  public void beforeTest() 
  {
	  WebDriverManager.chromedriver().setup();
	  driver=new ChromeDriver();
	  driver.manage().window().maximize();
	  driver.get("http://tutorialsninja.com/demo/index.php?route=common/home");	  
  }

  @AfterTest
  public void afterTest() 
  {
	  driver.close();
  }

}
