package addcartwithoutlogin;

import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

import org.testng.annotations.BeforeTest;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;

public class Addcart 
{
	WebDriver driver;
	@Test
	public void cart() throws InterruptedException, IOException 
	{
		WebElement sea =driver.findElement(By.name("search"));
		sea.sendKeys("mac");
		WebElement ser = driver.findElement(By.xpath("/html[1]/body[1]/header[1]/div[1]/div[1]/div[2]/div[1]/span[1]/button[1]"));
		ser.click();

		driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[3]/div[2]/div[1]/div[2]/div[2]/button[1]/span[1]")).click();

		WebDriverWait wait =new WebDriverWait(driver,20);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[contains(text(),'shopping cart')]")));
		driver.findElement(By.xpath("//a[contains(text(),'shopping cart')]")).click();
		
		
		Thread.sleep(2000);
		driver.findElement(By.xpath("//a[contains(text(),'Checkout')]")).click();
		
		Thread.sleep(2000);
		driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[2]/label[1]/input[1]")).click();
		
		driver.findElement(By.id("button-account")).click();
		
		
		File f = new File ("D:\\Finaltutorialsninja\\Data\\SignaUp.xlsx");
		FileInputStream fis =new FileInputStream(f);
		XSSFWorkbook wk = new XSSFWorkbook(fis);
		XSSFSheet sh= wk.getSheet("Sheet5");

		
			
			WebElement fname= driver.findElement(By.id("input-payment-firstname"));
			
			WebElement lname= driver.findElement(By.id("input-payment-lastname"));
			WebElement email= driver.findElement(By.id("input-payment-email"));
			WebElement mob= driver.findElement(By.id("input-payment-telephone"));
			WebElement com= driver.findElement(By.id("input-payment-company"));
			WebElement Addr= driver.findElement(By.id("input-payment-address-1"));
			WebElement Addr1= driver.findElement(By.id("input-payment-address-2"));
			WebElement city= driver.findElement(By.id("input-payment-city"));
			WebElement post= driver.findElement(By.name("postcode"));
		
			
			String fn = sh.getRow(0).getCell(0).toString();
			String l= sh.getRow(1).getCell(0).toString();
			String e= sh.getRow(2).getCell(0).toString();
			String m= sh.getRow(3).getCell(0).toString();
			String c= sh.getRow(4).getCell(0).toString();
			String A1= sh.getRow(5).getCell(0).toString();
			String A2= sh.getRow(6).getCell(0).toString();
			String c1= sh.getRow(7).getCell(0).toString();
			String p= sh.getRow(8).getCell(0).toString();
			
			
			System.out.println(fn+  " |   " +l+ "     |   "+e+ "   |   " +m+ "    |   "+c+ "    |    "+A1+"    |    "+A2+"    |     "+c1+"     |     "+p);
			
			fname.sendKeys(fn);
			lname.sendKeys(l);
			email.sendKeys(e);
			mob.sendKeys(m);
			com.sendKeys(c);
			Addr.sendKeys(A1);
			Addr1.sendKeys(A2);
			city.sendKeys(c1);
			post.sendKeys(p);
			
			Select dropdown = new Select(driver.findElement(By.id("input-payment-country")));  
			dropdown.selectByVisibleText("India");  
			
			Thread.sleep(2000);
			
			Select drop = new Select(driver.findElement(By.id("input-payment-zone")));  
			drop.selectByVisibleText("Maharashtra");
			
			
			driver.findElement(By.id("button-guest")).click();
			
			Thread.sleep(3000);
			WebElement che = driver.findElement(By.name("agree"));
		    che.click();
			
			
			
			
			
	
	}
	@BeforeTest
	public void beforeTest() 
	{
		WebDriverManager.chromedriver().setup();
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://tutorialsninja.com/demo/index.php?route=common/home");
	}

	@AfterTest
	public void afterTest() 
	{
		driver.close();
	}

}
