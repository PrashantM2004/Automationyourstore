package title;

import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

import org.testng.annotations.BeforeTest;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

public class Title
{
	WebDriver driver;
  @Test
  public void titlechecking() 
  {
	  WebElement tablet = driver.findElement(By.linkText("Tablets"));
	  tablet.click();
	  String t1= driver.getTitle();
	  System.out.println("Title of the page is "+t1);
	  String t2="tablets";
	  if(t1.equalsIgnoreCase(t2))
	  {
		  System.out.println("page  is found");
		  
	  }
	  else
	  {
		  System.out.println("page is not found ");
	  }
	  
  }
  @BeforeTest
  public void beforeTest() 
  {
	  WebDriverManager.chromedriver().setup();
		
	  driver=new ChromeDriver();
	  driver.manage().window().maximize();
	  driver.get("http://tutorialsninja.com/demo/index.php?route=common/home");
  }

  @AfterTest
  public void afterTest() 
  {
	  driver.close();
  }

}
