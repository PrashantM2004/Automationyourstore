package addtocart;

import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

import org.testng.annotations.BeforeTest;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;

public class AddCart 
{
	WebDriver driver;
  @Test
  public void addcart()
  {
	  
	  WebDriverWait wait =new WebDriverWait(driver,20);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'My Account')]")));
		driver.findElement(By.xpath("//span[contains(text(),'My Account')]")).click();
		
		//wd.findElement(By.xpath("//span[contains(text(),'My Account')]"));
		driver.findElement(By.xpath("/html/body/nav/div/div[2]/ul/li[2]/ul/li[2]/a")).click();
	  WebElement usernm = driver.findElement(By.name("email"));
		WebElement pswd = driver.findElement(By.name("password"));
		WebElement login = driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[1]/div[2]/div[1]/form[1]/input[1]"));
		
		usernm.sendKeys("prashantmane123@gmail.com");
		pswd.sendKeys("Ram@123");
		login.click();
		
	  WebElement sea =driver.findElement(By.name("search"));
	  sea.sendKeys("mac");
	  
	  WebElement ser = driver.findElement(By.xpath("/html[1]/body[1]/header[1]/div[1]/div[1]/div[2]/div[1]/span[1]/button[1]"));
		ser.click();
	  
		driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[3]/div[1]/div[1]/div[2]/div[2]/button[1]")).click();
		WebDriverWait wait1 =new WebDriverWait(driver,20);
		wait1.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'My Account')]")));
		driver.findElement(By.xpath("//span[contains(text(),'My Account')]")).click();
		driver.findElement(By.linkText("Logout")).click();
	  
	  
  }
  @BeforeTest
  public void beforeTest()
  {
	  WebDriverManager.chromedriver().setup();
	  driver=new ChromeDriver();
	  driver.manage().window().maximize();
	  driver.get("http://tutorialsninja.com/demo/index.php?route=common/home");
	  
  }

  @AfterTest
  public void afterTest() 
  {
	  driver.close();
	  
  }

}
